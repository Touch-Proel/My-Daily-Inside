import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, User, ArrowRight } from 'lucide-react';
import { BlogPost } from '../../types';
import { formatDate } from '../../lib/utils';

export const BlogCard: React.FC<{ post: BlogPost; variant?: 'default' | 'featured' | 'small' }> = ({ post, variant = 'default' }) => {
  if (variant === 'featured') {
    return (
      <Link 
        to={`/post/${post.slug}`}
        className="group grid grid-cols-1 lg:grid-cols-2 gap-8 items-center bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300"
      >
        <div className="h-[300px] lg:h-[450px] overflow-hidden">
          <img 
            src={post.image} 
            alt={post.title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <div className="p-8 lg:p-12 space-y-6">
          <div className="inline-flex px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-xs font-bold uppercase tracking-wider">
            {post.category}
          </div>
          <h2 className="text-3xl md:text-4xl font-bold font-display leading-tight group-hover:text-blue-600 transition-colors">
            {post.title}
          </h2>
          <p className="text-gray-500 text-lg line-clamp-3">
            {post.description}
          </p>
          <div className="flex items-center gap-6 pt-4 border-t border-gray-50">
            <div className="flex items-center gap-2 text-sm text-gray-500 font-medium">
              <User className="w-4 h-4 text-gray-400" />
              {post.author}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <Clock className="w-4 h-4" />
              {post.readingTime}
            </div>
          </div>
        </div>
      </Link>
    );
  }

  if (variant === 'small') {
    return (
      <Link to={`/post/${post.slug}`} className="group flex gap-4 items-start py-4">
        <div className="flex-shrink-0 w-24 h-24 rounded-xl overflow-hidden">
          <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
        </div>
        <div>
          <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest block mb-1">{post.category}</span>
          <h4 className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors line-clamp-2 leading-tight">
            {post.title}
          </h4>
          <span className="text-xs text-gray-400 mt-1 block">{formatDate(post.publishedAt)}</span>
        </div>
      </Link>
    );
  }

  return (
    <Link 
      to={`/post/${post.slug}`}
      className="group flex flex-col bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300"
    >
      <div className="relative h-56 overflow-hidden">
        <img 
          src={post.image} 
          alt={post.title} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-white/95 backdrop-blur shadow-sm text-blue-600 rounded-lg text-[10px] font-bold uppercase tracking-wider">
            {post.category}
          </span>
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold font-display mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
          {post.title}
        </h3>
        <p className="text-gray-500 text-sm line-clamp-2 mb-6 flex-grow">
          {post.description}
        </p>
        <div className="flex items-center justify-between pt-4 border-t border-gray-50">
          <span className="text-xs text-gray-400 flex items-center gap-1 font-medium italic">
            {formatDate(post.publishedAt)}
          </span>
          <div className="flex items-center gap-1 text-blue-600 text-xs font-bold uppercase tracking-widest group-hover:translate-x-1 transition-transform">
            Read More <ArrowRight className="w-3 h-3" />
          </div>
        </div>
      </div>
    </Link>
  );
};
