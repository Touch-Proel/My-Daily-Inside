import React from 'react';
import { Header } from './Header';
import { Footer } from './Footer';
import { AdSlot } from './AdSlot';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      {/* Top Ad Slot (Global) */}
      <div className="max-w-7xl mx-auto px-4 w-full h-fit">
        <AdSlot label="Leaderboard Ad - High Visibility" type="horizontal" className="my-4" />
      </div>

      <main className="flex-grow">
        {children}
      </main>

      <div className="max-w-7xl mx-auto px-4 w-full h-fit">
        <AdSlot label="Bottom Ad - Before Footer" type="horizontal" className="my-12" />
      </div>

      <Footer />
    </div>
  );
};
