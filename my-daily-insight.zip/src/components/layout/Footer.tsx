import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Github, Mail } from 'lucide-react';
import { CATEGORIES } from '../../constants/blogData';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="bg-blue-600 p-2 rounded-lg group-hover:bg-blue-500 transition-colors">
                <div className="w-5 h-5 border-2 border-white rounded-sm transform rotate-45 flex items-center justify-center font-bold text-white text-xs">
                  M
                </div>
              </div>
              <span className="text-xl font-bold font-display tracking-tight text-white">
                My Daily <span className="text-blue-500">Insight</span>
              </span>
            </Link>
            <p className="text-gray-400 leading-relaxed">
              Empowering your journey with actionable insights on productivity, technology, and personal growth. Your daily dose of clarity in a complex world.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-blue-500 transition-colors p-2 bg-gray-800 rounded-lg"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="hover:text-blue-500 transition-colors p-2 bg-gray-800 rounded-lg"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="hover:text-blue-500 transition-colors p-2 bg-gray-800 rounded-lg"><Linkedin className="w-5 h-5" /></a>
              <a href="#" className="hover:text-blue-500 transition-colors p-2 bg-gray-800 rounded-lg"><Github className="w-5 h-5" /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold mb-6 font-display">Explore Categories</h3>
            <ul className="space-y-4">
              {CATEGORIES.map((cat) => (
                <li key={cat.slug}>
                  <Link to={`/category/${cat.slug}`} className="hover:text-blue-500 transition-colors block">
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Useful Stuff */}
          <div>
            <h3 className="text-white font-bold mb-6 font-display">Company</h3>
            <ul className="space-y-4">
              <li><Link to="/about" className="hover:text-blue-500 transition-colors block">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-blue-500 transition-colors block">Contact Us</Link></li>
              <li><Link to="/privacy-policy" className="hover:text-blue-500 transition-colors block">Privacy Policy</Link></li>
              <li><Link to="/terms-conditions" className="hover:text-blue-500 transition-colors block">Terms & Conditions</Link></li>
              <li><Link to="/disclaimer" className="hover:text-blue-500 transition-colors block">Disclaimer</Link></li>
            </ul>
          </div>

          {/* Newsletter / Contact */}
          <div>
            <h3 className="text-white font-bold mb-6 font-display">Get in Touch</h3>
            <p className="mb-6 text-gray-400">Have a question or looking to collaborate?</p>
            <a 
              href="mailto:contact@mydailyinsight.com" 
              className="flex items-center gap-3 bg-gray-800 p-4 rounded-xl border border-gray-700 hover:border-blue-500/50 transition-all group"
            >
              <div className="bg-blue-600/20 p-2 rounded-lg">
                <Mail className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase">Email us at</p>
                <p className="text-white group-hover:text-blue-400 transition-colors">hello@mydailyinsight.com</p>
              </div>
            </a>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500">
            &copy; {currentYear} My Daily Insight. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-gray-500">
            <Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms</Link>
            <Link to="/cookies" className="hover:text-white transition-colors">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
