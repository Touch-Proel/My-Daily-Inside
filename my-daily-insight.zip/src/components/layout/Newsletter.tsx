import React, { useState } from 'react';
import { Mail, ArrowRight, CheckCircle2 } from 'lucide-react';
import { cn } from '../../lib/utils';

export const Newsletter: React.FC<{ className?: string }> = ({ className }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <div className={cn("bg-blue-600 rounded-2xl p-8 md:p-12 text-white relative overflow-hidden", className)}>
      <div className="relative z-10 max-w-2xl">
        <h2 className="text-3xl font-bold mb-4 font-display">Join the Modern Insight Newsletter</h2>
        <p className="text-blue-100 text-lg mb-8">
          Get weekly tips on AI tools, productivity systems, and personal growth delivered straight to your inbox. No spam, ever.
        </p>

        {subscribed ? (
          <div className="flex items-center gap-3 bg-blue-700/50 p-4 rounded-xl border border-blue-400/30">
            <CheckCircle2 className="w-6 h-6 text-blue-200" />
            <p className="font-medium">Thanks for subscribing! Check your inbox soon.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-grow">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
              <input
                type="email"
                placeholder="Enter your email address"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-xl py-4 pl-12 pr-4 text-white placeholder:text-blue-200 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all"
              />
            </div>
            <button
              type="submit"
              className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold hover:bg-blue-50 transition-colors flex items-center justify-center gap-2 group"
            >
              Subscribe Now
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
        )}
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-black/10 rounded-full blur-2xl -ml-24 -mb-24"></div>
    </div>
  );
};
