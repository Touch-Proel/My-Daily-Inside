import React from 'react';

interface AdSlotProps {
  label: string;
  className?: string;
  type?: 'horizontal' | 'vertical' | 'square';
  heightClass?: string;
}

export const AdSlot: React.FC<AdSlotProps> = ({ label, className, type = 'horizontal', heightClass: customHeightClass }) => {
  const heightClass = customHeightClass || (type === 'horizontal' ? 'h-24' : type === 'vertical' ? 'h-[600px]' : 'h-64');
  const widthClass = type === 'vertical' ? 'w-[300px]' : 'w-full';

  return (
    <div className={`my-8 flex items-center justify-center bg-gray-50 border border-dashed border-gray-300 rounded overflow-hidden ${heightClass} ${widthClass} ${className}`}>
      <div className="text-center">
        <span className="text-[10px] uppercase tracking-widest text-gray-400 block mb-1">Advertisement</span>
        <span className="text-gray-500 font-medium">{label}</span>
      </div>
    </div>
  );
};
