import React from 'react';
import { Users, Target, Zap, Shield, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export const About: React.FC = () => {
  return (
    <div className="pb-20">
      <section className="pt-20 pb-20 bg-gray-50 overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-block px-4 py-1.5 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-widest mb-6">
            Our Story
          </div>
          <h1 className="text-5xl md:text-7xl font-bold font-display text-gray-900 mb-8 max-w-4xl mx-auto leading-tight italic">
            Navigating the Digital age with <span className="text-blue-600">Clarity</span>.
          </h1>
          <p className="text-xl text-gray-500 max-w-3xl mx-auto leading-relaxed">
            Welcome to My Daily Insight. We believe that in an era of information overload, the most valuable skills are discernment, deep focus, and strategic action.
          </p>
        </div>
        
        {/* Background elements */}
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none select-none">
          <div className="absolute top-1/4 right-0 text-[300px] font-display font-bold leading-none -mr-20">INSIGHT</div>
        </div>
      </section>

      {/* Mission */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 mb-24 relative z-20">
        <div className="bg-white rounded-[40px] shadow-2xl p-12 md:p-20 border border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
            <div className="md:col-span-2 space-y-10">
              <div>
                <h2 className="text-3xl font-bold font-display mb-6">Who We Are</h2>
                <p className="text-gray-600 text-lg leading-relaxed">
                  Founded in 2024, My Daily Insight started as a small personal project to document the intersection of productivity and the then-emerging AI revolution. Today, we've grown into a trusted resource for over 12,000 monthly readers looking for actionable advice.
                </p>
              </div>
              <div>
                <h2 className="text-3xl font-bold font-display mb-6">Our Mission</h2>
                <p className="text-gray-600 text-lg leading-relaxed">
                  Our mission is simple: to help you build a better relationship with technology and your work. We don't just review apps; we analyze systems. We don't just talk about "hustle"; we talk about sustainable high-performance and holistic growth.
                </p>
              </div>
            </div>
            
            <div className="space-y-8">
              <div className="p-8 bg-blue-50 rounded-3xl border border-blue-100">
                <h4 className="text-blue-700 font-bold font-display mb-4 flex items-center gap-2 uppercase tracking-tight italic">
                  <Target className="w-5 h-5" /> Our Goals
                </h4>
                <ul className="space-y-4 text-gray-600 font-medium italic">
                  <li className="flex items-start gap-2">
                    <Zap className="w-4 h-4 text-blue-400 mt-1 flex-shrink-0" />
                    Provide clarity in a noisy digital environment.
                  </li>
                   <li className="flex items-start gap-2">
                    <Zap className="w-4 h-4 text-blue-400 mt-1 flex-shrink-0" />
                    Review tools based on real utility, not hype.
                  </li>
                   <li className="flex items-start gap-2">
                    <Zap className="w-4 h-4 text-blue-400 mt-1 flex-shrink-0" />
                    Share long-term sustainable strategies for growth.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-white pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold font-display italic">The Pillars of Insight</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-10 rounded-3xl bg-gray-50 hover:bg-blue-50 border border-transparent hover:border-blue-100 transition-all duration-300">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm mb-8">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold font-display mb-4">Integrity First</h3>
              <p className="text-gray-500 leading-relaxed italic">
                We only recommend tools we've actually used. Our reviews are unbiased, honest, and aimed at providing you with the best outcome.
              </p>
            </div>
            <div className="p-10 rounded-3xl bg-gray-50 hover:bg-blue-50 border border-transparent hover:border-blue-100 transition-all duration-300">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm mb-8">
                <Shield className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold font-display mb-4">Deep Value</h3>
              <p className="text-gray-500 leading-relaxed italic">
                We avoid "shallow" content. Every article must offer a unique perspective or a concrete takeaway that you can apply today.
              </p>
            </div>
            <div className="p-10 rounded-3xl bg-gray-50 hover:bg-blue-50 border border-transparent hover:border-blue-100 transition-all duration-300">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm mb-8">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold font-display mb-4">Growth Focused</h3>
              <p className="text-gray-500 leading-relaxed italic">
                We believe in the power of compound gains. Small improvements in your daily habits lead to massive results over time.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to action */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-blue-600 rounded-[40px] p-12 md:p-20 text-center text-white relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-4xl md:text-5xl font-bold font-display mb-8 italic">Ready to transform your work?</h2>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/category/technology-ai" className="bg-white text-blue-600 px-10 py-4 rounded-2xl font-bold hover:bg-blue-50 transition-colors uppercase tracking-tight">Browse Tech Guides</Link>
              <Link to="/contact" className="bg-blue-700 text-white border border-white/20 px-10 py-4 rounded-2xl font-bold hover:bg-blue-800 transition-colors uppercase tracking-tight">Contact Us</Link>
            </div>
          </div>
          {/* Decorative shapes */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-black/5 rounded-full -ml-48 -mb-48"></div>
        </div>
      </section>
    </div>
  );
};
