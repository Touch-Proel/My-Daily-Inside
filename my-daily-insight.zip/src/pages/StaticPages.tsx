import React from 'react';
import { Shield, FileText, AlertCircle, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const PageWrapper: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => (
  <div className="pb-20">
    <header className="bg-gray-900 text-white pt-20 pb-20 overflow-hidden relative">
      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <nav className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500 mb-8">
          <Link to="/" className="hover:text-white transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <span>Legal</span>
        </nav>
        <div className="flex items-center gap-4 mb-6">
          <div className="bg-blue-600 p-3 rounded-2xl text-white shadow-lg shadow-blue-500/20">
            {icon}
          </div>
          <h1 className="text-4xl md:text-5xl font-bold font-display italic">{title}</h1>
        </div>
        <p className="text-gray-400 text-lg sm:text-xl font-medium max-w-2xl leading-relaxed italic">
          Transparency and trust are the cornerstones of the My Daily Insight community.
        </p>
      </div>
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-[100px] -mr-48 -mt-48 pointer-events-none"></div>
    </header>

    <main className="max-w-4xl mx-auto px-4 -mt-10 relative z-20">
      <div className="bg-white rounded-[40px] p-8 md:p-16 shadow-2xl border border-gray-100 prose prose-slate max-w-none">
        {children}
      </div>
    </main>
  </div>
);

export const PrivacyPolicy: React.FC = () => (
  <PageWrapper title="Privacy Policy" icon={<Shield className="w-8 h-8" />}>
    <p>Last Updated: April 25, 2026</p>
    <p>At My Daily Insight, we take your privacy seriously. This policy outlines how we collect, use, and protect your information when you visit our website.</p>
    
    <h3>1. Information We Collect</h3>
    <p>We collect information you provide directly (such as your email for newsletters) and information collected automatically through cookies and similar technologies when you navigate our site.</p>
    
    <h3>2. How We Use Information</h3>
    <p>We use the collected information to:</p>
    <ul>
      <li>Deliver newsletters and content you've requested.</li>
      <li>Improve our website performance and user experience.</li>
      <li>Analyze site traffic and trends.</li>
      <li>Display relevant advertisements via partners like Google AdSense.</li>
    </ul>
    
    <h3>3. Third-Party Partners</h3>
    <p>We use Google AdSense and other third-party services to display ads. These partners may use cookies to serve ads based on your prior visits to this and other websites.</p>
    
    <h3>4. Your Choices</h3>
    <p>You can opt-out of personalized advertising by visiting Google's Ads Settings. You can also unsubscribe from our newsletter at any time via the link in the footer of our emails.</p>
  </PageWrapper>
);

export const TermsConditions: React.FC = () => (
  <PageWrapper title="Terms & Conditions" icon={<FileText className="w-8 h-8" />}>
    <p>Last Updated: April 25, 2026</p>
    <p>Welcome to My Daily Insight. By accessing this website, we assume you accept these terms and conditions in full. Do not continue to use My Daily Insight if you do not accept all of the terms and conditions stated on this page.</p>
    
    <h3>1. License</h3>
    <p>Unless otherwise stated, My Daily Insight and/or its licensors own the intellectual property rights for all material on My Daily Insight. All intellectual property rights are reserved.</p>
    
    <h3>2. User Comments</h3>
    <p>Certain parts of this website offer an opportunity for users to post and exchange opinions, information, and data. My Daily Insight does not screen, edit, publish or review Comments prior to their appearance on the website and Comments do not reflect the views or opinions of My Daily Insight.</p>
    
    <h3>3. Content Liability</h3>
    <p>We shall have no responsibility or liability for any content appearing on your Web site. You agree to indemnify and defend us against all claims arising out of or based upon your Website.</p>
  </PageWrapper>
);

export const Disclaimer: React.FC = () => (
  <PageWrapper title="Disclaimer" icon={<AlertCircle className="w-8 h-8" />}>
    <p>Last Updated: April 25, 2026</p>
    <p>The information provided by My Daily Insight ("we," "us," or "our") on this website is for general informational purposes only. All information on the site is provided in good faith, however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the site.</p>
    
    <h3>1. Professional Advice</h3>
    <p>The site cannot and does not contain professional advice (financial, legal, or medical). The information is provided for general informational and educational purposes only and is not a substitute for professional advice.</p>
    
    <h3>2. Affiliate Disclosure</h3>
    <p>This site may contain links to affiliate websites, and we receive an affiliate commission for any purchases made by you on the affiliate website using such links. This does not result in any additional cost to you.</p>
    
    <h3>3. Advertising</h3>
    <p>This website uses Google AdSense for advertising. We are not responsible for the content, products, or services advertised via the AdSense network.</p>
  </PageWrapper>
);
