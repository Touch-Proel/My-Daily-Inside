import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  LayoutDashboard, 
  FilePlus, 
  Settings, 
  Eye, 
  Save, 
  Loader2, 
  Image as ImageIcon, 
  Tag, 
  User, 
  Calendar,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Wand2,
  Search,
  Trash2,
  Edit,
  ExternalLink,
  ChevronRight,
  Plus
} from 'lucide-react';
import { auth } from '../lib/firebase';
import { blogService } from '../services/blogService';
import { CATEGORIES } from '../constants/blogData';
import { generateArticle } from '../services/geminiService';
import { BlogPost } from '../types';

type AdminView = 'posts' | 'create' | 'edit';

export const Admin: React.FC = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<AdminView>('posts');
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const navigate = useNavigate();

  const initialFormData = {
    title: '',
    slug: '',
    description: '',
    content: '',
    category: CATEGORIES[0].name,
    image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&q=80&w=2070',
    readingTime: '5 min read',
    author: 'Admin',
    publishedAt: new Date().toISOString().slice(0, 16)
  };

  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    return onAuthStateChanged(auth, (user) => {
      if (user && user.email === 'prolseangly@gmail.com') {
        setIsAdmin(true);
        setFormData(prev => ({ ...prev, author: user.displayName || 'Admin' }));
        fetchPosts();
      } else {
        setIsAdmin(false);
        if (!loading) navigate('/');
      }
      setLoading(false);
    });
  }, [navigate]);

  const fetchPosts = async () => {
    try {
      const results = await blogService.getPosts(undefined, 100, true);
      setPosts(results);
    } catch (error) {
      console.error("Failed to fetch posts:", error);
    }
  };

  const handleEditInit = (post: BlogPost) => {
    setEditingId(post.id);
    setFormData({
      title: post.title,
      slug: post.slug,
      description: post.description,
      content: post.content,
      category: post.category,
      image: post.image,
      readingTime: post.readingTime,
      author: post.author,
      publishedAt: post.publishedAt ? new Date(post.publishedAt).toISOString().slice(0, 16) : new Date().toISOString().slice(0, 16)
    });
    setView('edit');
    window.scrollTo(0, 0);
  };

  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    setIsSubmitting(true);
    setMessage(null);
    
    try {
      await blogService.deletePost(id);
      setPosts(prev => prev.filter(p => p.id !== id));
      setMessage({ type: 'success', text: 'Post deleted successfully.' });
      setDeletingId(null);
    } catch (error: any) {
      console.error("Delete failed:", error);
      let errorMsg = 'Failed to delete post.';
      try {
        const parsed = JSON.parse(error.message);
        errorMsg = `Permission Denied: ${parsed.operationType} on ${parsed.path}`;
      } catch (e) {
        // Not a JSON error
      }
      setMessage({ type: 'error', text: errorMsg });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreateNew = () => {
    setEditingId(null);
    setFormData(initialFormData);
    setView('create');
    setMessage(null);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const newData = { ...prev, [name]: value };
      // Auto-generate slug from title if slug is empty or it was generated from title before
      if (name === 'title' && (!prev.slug || !prev.slug.includes('-'))) {
        newData.slug = value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      }
      return newData;
    });
  };

  const handleAiGenerate = async () => {
    if (!aiPrompt) {
      alert("Please enter a topic for the AI to write about.");
      return;
    }

    setIsGenerating(true);
    setMessage(null);
    try {
      const generated = await generateArticle(aiPrompt, formData.category);
      
      // Post-process the content to ensure actual newlines and no repeated titles
      let cleanContent = generated.content;
      if (cleanContent.startsWith(generated.title)) {
        cleanContent = cleanContent.slice(generated.title.length).trim();
      }
      
      setFormData(prev => ({
        ...prev,
        title: generated.title,
        slug: generated.slug,
        description: generated.description,
        content: cleanContent,
        readingTime: generated.readingTime
      }));
      setMessage({ type: 'success', text: 'AI Article generated! Please review and publish.' });
    } catch (error: any) {
      console.error(error);
      setMessage({ type: 'error', text: error.message || 'Failed to generate article.' });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage(null);

    try {
      const formattedData = {
        ...formData,
        publishedAt: new Date(formData.publishedAt).toISOString()
      };

      if (view === 'edit' && editingId) {
        await blogService.updatePost(editingId, {
          ...formattedData,
          updatedAt: new Date().toISOString()
        } as any);
        setMessage({ type: 'success', text: 'Post updated successfully!' });
      } else {
        await blogService.createPost(formattedData as any);
        setMessage({ type: 'success', text: 'Post published successfully!' });
      }
      
      await fetchPosts();
      setView('posts');
      setFormData(initialFormData);
      setAiPrompt('');
    } catch (error) {
      console.error(error);
      setMessage({ type: 'error', text: 'Failed to save post. Check console for details.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredPosts = posts.filter(post => 
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-100 hidden lg:flex flex-col fixed inset-y-0">
        <div className="p-8">
          <div 
            onClick={() => navigate('/')}
            className="flex items-center gap-3 text-blue-600 mb-12 cursor-pointer"
          >
            <LayoutDashboard className="w-8 h-8" />
            <span className="font-bold text-2xl tracking-tighter">ADMIN</span>
          </div>
          
          <nav className="space-y-2">
            <button 
              onClick={() => setView('posts')}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all ${
                view === 'posts' ? 'text-blue-600 bg-blue-50 shadow-sm' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
              Manage Posts
            </button>
            <button 
              onClick={handleCreateNew}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl font-bold transition-all ${
                (view === 'create' || view === 'edit') ? 'text-blue-600 bg-blue-50 shadow-sm' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <FilePlus className="w-5 h-5" />
              {editingId ? 'Edit Post' : 'Create New'}
            </button>
            <hr className="border-gray-50 my-4" />
            <button className="w-full flex items-center gap-4 px-5 py-4 text-gray-400 hover:text-gray-600 rounded-2xl font-bold transition-all">
              <Settings className="w-5 h-5" />
              Settings
            </button>
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow lg:ml-64 p-4 md:p-8 lg:p-12">
        <div className="max-w-5xl mx-auto">
          {view === 'posts' && (
            <div className="space-y-8">
              <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                  <h1 className="text-4xl font-black text-gray-900 tracking-tight">Manage Posts</h1>
                  <p className="text-gray-500 font-medium italic">You have {posts.length} articles published</p>
                </div>
                <button 
                  onClick={handleCreateNew}
                  className="bg-blue-600 text-white px-8 py-3 rounded-full font-bold hover:bg-blue-700 transition-all flex items-center gap-2 shadow-lg shadow-blue-200"
                >
                  <Plus className="w-5 h-5" />
                  New Article
                </button>
              </header>

              {message && (
                <div className={`p-4 rounded-2xl flex items-center gap-3 ${
                  message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                }`}>
                  {message.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                  <span className="font-bold">{message.text}</span>
                </div>
              )}

              {/* Search and Filters */}
              <div className="relative">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 w-5 h-5" />
                <input 
                  type="text"
                  placeholder="Search articles by title or category..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white border border-gray-100 rounded-3xl py-5 pl-16 pr-8 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all text-gray-900 font-medium shadow-sm"
                />
              </div>

              {/* Posts Table */}
              <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-gray-50/50">
                        <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Article</th>
                        <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Category</th>
                        <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Published</th>
                        <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50 text-sm">
                      {filteredPosts.map((post) => (
                        <tr key={post.id} className="hover:bg-gray-50/50 transition-colors group">
                          <td className="px-8 py-6">
                            <div className="flex items-center gap-4">
                              <img src={post.image} className="w-12 h-12 rounded-xl object-cover shadow-sm bg-gray-100" />
                              <div>
                                <h3 className="font-bold text-gray-900 leading-tight group-hover:text-blue-600 transition-colors">{post.title}</h3>
                                <p className="text-gray-400 text-xs mt-1 italic">/blog/{post.slug}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-8 py-6">
                            <span className="px-4 py-1.5 rounded-full bg-blue-50 text-blue-600 font-bold text-[10px] uppercase">
                              {post.category}
                            </span>
                          </td>
                          <td className="px-8 py-6 text-gray-500 font-medium">
                            {new Date(post.publishedAt).toLocaleDateString()}
                          </td>
                          <td className="px-8 py-6 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button 
                                onClick={() => navigate(`/blog/${post.slug}`)}
                                className="p-2 text-gray-400 hover:text-blue-600 transition-all"
                                title="View Live"
                              >
                                <ExternalLink className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={() => handleEditInit(post)}
                                className="p-2 text-gray-400 hover:text-blue-600 transition-all"
                                title="Edit"
                              >
                                <Edit className="w-5 h-5" />
                              </button>
                              {deletingId === post.id ? (
                                <div className="flex items-center gap-2">
                                  <button 
                                    disabled={isSubmitting}
                                    onClick={() => handleDelete(post.id)}
                                    className="px-3 py-1 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 disabled:opacity-50"
                                  >
                                    Confirm
                                  </button>
                                  <button 
                                    disabled={isSubmitting}
                                    onClick={() => setDeletingId(null)}
                                    className="px-3 py-1 bg-gray-200 text-gray-700 rounded-lg text-xs font-bold hover:bg-gray-300 disabled:opacity-50"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <button 
                                  onClick={() => setDeletingId(post.id)}
                                  className="p-2 text-gray-400 hover:text-red-500 transition-all"
                                  title="Delete"
                                >
                                  <Trash2 className="w-5 h-5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                      {filteredPosts.length === 0 && (
                        <tr>
                          <td colSpan={4} className="px-8 py-20 text-center text-gray-400 italic">
                            No articles found matching your search.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {(view === 'create' || view === 'edit') && (
            <div className="space-y-12">
              <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <button 
                    onClick={() => setView('posts')}
                    className="text-blue-600 font-bold text-sm mb-2 flex items-center gap-1 hover:underline underline-offset-4"
                  >
                    <ChevronRight className="w-4 h-4 rotate-180" /> Back to Dashboard
                  </button>
                  <h1 className="text-4xl font-black text-gray-900 tracking-tight">
                    {editingId ? 'Edit Article' : 'Create Article'}
                  </h1>
                </div>
              </header>

              {/* AI Generator Card only for creation */}
              {!editingId && (
                <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2.5rem] p-8 md:p-10 text-white shadow-xl shadow-blue-200">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-md">
                      <Sparkles className="w-7 h-7" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold">AI SEO Assistant</h2>
                      <p className="text-blue-100 text-sm font-medium">Generate high-quality articles in seconds</p>
                    </div>
                  </div>
                  
                  <div className="space-y-5">
                    <div className="relative">
                      <textarea 
                        value={aiPrompt}
                        onChange={(e) => setAiPrompt(e.target.value)}
                        placeholder="What should this article be about? (e.g., '10 Hidden Benefits of Daily Power Naps')"
                        className="w-full bg-white/10 border-2 border-white/10 rounded-3xl py-5 px-8 focus:outline-none focus:ring-4 focus:ring-white/30 placeholder:text-blue-100/50 text-white italic resize-none text-lg"
                        rows={3}
                      />
                    </div>
                    <button 
                      onClick={handleAiGenerate}
                      disabled={isGenerating || !aiPrompt}
                      className="w-full bg-white text-blue-700 py-5 rounded-full font-black hover:bg-blue-50 transition-all flex items-center justify-center gap-3 shadow-xl shadow-blue-900/20 disabled:opacity-50"
                    >
                      {isGenerating ? <Loader2 className="w-6 h-6 animate-spin" /> : <Wand2 className="w-5 h-5" />}
                      {isGenerating ? 'AI IS CRAFTING YOUR STORY...' : 'GENERATE UNIQUE SEO ARTICLE'}
                    </button>
                  </div>
                </div>
              )}

          {message && (
            <div className={`mb-8 p-4 rounded-2xl flex items-center gap-3 ${
              message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'
            }`}>
              {message.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
              <span className="font-bold">{message.text}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="bg-white rounded-[2rem] p-8 md:p-10 shadow-sm border border-gray-100 space-y-8">
              {/* Title Section */}
              <div className="space-y-4">
                <label className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Article Title</label>
                <input 
                  required
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  type="text" 
                  placeholder="Enter a catchy title..." 
                  className="w-full text-2xl md:text-3xl font-bold text-gray-900 placeholder:text-gray-200 border-none focus:ring-0 p-0"
                />
                <div className="flex items-center gap-2 text-gray-400 italic text-sm">
                  <span>URL Slug:</span>
                  <input 
                    name="slug"
                    value={formData.slug}
                    onChange={handleChange}
                    className="bg-transparent border-none focus:ring-0 p-0 text-blue-500 font-medium italic underline decoration-dotted w-full"
                  />
                </div>
              </div>

              <hr className="border-gray-50" />

              {/* Meta Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-sm">
                <div className="space-y-4">
                  <label className="flex items-center gap-2 text-xs font-black text-gray-400 uppercase tracking-[0.2em] ml-2">
                    <Tag className="w-3 h-3" /> Category
                  </label>
                  <select 
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-bold italic appearance-none"
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat.name} value={cat.name}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-4">
                  <label className="flex items-center gap-2 text-xs font-black text-gray-400 uppercase tracking-[0.2em] ml-2">
                    <ImageIcon className="w-3 h-3" /> Hero Image URL
                  </label>
                  <input 
                    name="image"
                    value={formData.image}
                    onChange={handleChange}
                    type="url" 
                    placeholder="https://images.unsplash.com/..." 
                    className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium italic"
                  />
                </div>
                <div className="space-y-4">
                  <label className="flex items-center gap-2 text-xs font-black text-gray-400 uppercase tracking-[0.2em] ml-2">
                    <Calendar className="w-3 h-3" /> Publish Date
                  </label>
                  <input 
                    name="publishedAt"
                    value={formData.publishedAt}
                    onChange={handleChange}
                    type="datetime-local" 
                    className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium"
                  />
                </div>
              </div>

              {/* Content Section */}
              <div className="space-y-4">
                <label className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Content (Markdown Supported)</label>
                <textarea 
                  required
                  name="content"
                  value={formData.content}
                  onChange={handleChange}
                  rows={15}
                  placeholder="Start writing your masterpiece..."
                  className="w-full bg-gray-50 border border-gray-100 rounded-3xl py-6 px-8 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium italic resize-none leading-relaxed"
                />
              </div>

              {/* Excerpt Section */}
              <div className="space-y-4">
                <label className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Description / Excerpt</label>
                <textarea 
                  required
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={3}
                  placeholder="A short summary for social media and previews..."
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium italic resize-none leading-relaxed"
                />
              </div>
            </div>

                <div className="flex flex-col sm:flex-row justify-end gap-6 pb-20">
                  <button 
                    type="button"
                    onClick={() => {
                      setView('posts');
                      setMessage(null);
                    }}
                    className="px-10 py-5 rounded-full font-black text-gray-400 hover:text-gray-900 transition-all italic text-sm"
                  >
                    DISCARD CHANGES
                  </button>
                  <button 
                    disabled={isSubmitting}
                    type="submit"
                    className="bg-blue-600 text-white px-12 py-5 rounded-full font-black hover:bg-blue-700 transition-all flex items-center justify-center gap-3 shadow-2xl shadow-blue-200 disabled:opacity-50 text-sm tracking-widest uppercase"
                  >
                    {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    {isSubmitting ? 'SAVING...' : (editingId ? 'UPDATE POST' : 'PUBLISH ARTICLE')}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
