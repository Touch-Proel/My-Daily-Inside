import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, TrendingUp, Zap, Target, Loader2, Plus } from 'lucide-react';
import { BLOG_POSTS, CATEGORIES } from '../constants/blogData';
import { BlogCard } from '../components/blog/BlogCard';
import { Newsletter } from '../components/layout/Newsletter';
import { AdSlot } from '../components/layout/AdSlot';
import { blogService } from '../services/blogService';
import { BlogPost } from '../types';
import { auth } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

export const Home: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  useEffect(() => {
    return onAuthStateChanged(auth, (user) => {
      setIsAdmin(user?.email === 'prolseangly@gmail.com');
    });
  }, []);

  const loadPosts = async () => {
    setLoading(true);
    try {
      const results = await blogService.getPosts();
      setPosts(results);
    } catch (error) {
      console.error("Failed to fetch posts:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPosts();
  }, []);

  const handleSeed = async () => {
    setIsSeeding(true);
    try {
      await blogService.seedPosts(BLOG_POSTS);
      await loadPosts();
    } catch (error) {
      console.error("Seeding failed:", error);
      alert("Seeding failed. Make sure you are logged in as prolseangly@gmail.com");
    } finally {
      setIsSeeding(false);
    }
  };

  const featuredPost = posts[0] || (posts.length === 0 ? BLOG_POSTS[0] : null);
  const latestPosts = posts.length > 0 ? posts.slice(1) : (posts.length === 0 ? BLOG_POSTS.slice(1) : []);

  if (loading && posts.length === 0) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
        <p className="text-gray-500 font-medium italic">Fetching the latest insights...</p>
      </div>
    );
  }

  return (
    <div className="space-y-20 pb-20">
      {/* Admin Quick Action */}
      {isAdmin && posts.length === 0 && (
        <div className="bg-blue-600 text-white py-4 px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6 fill-yellow-400 text-yellow-400 animate-pulse" />
            <div>
              <p className="font-bold">Welcome back, Admin!</p>
              <p className="text-sm text-blue-100">Your live database is empty. Would you like to seed it with the demo content?</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <Link 
              to="/admin"
              className="bg-white text-blue-600 px-6 py-2 rounded-full font-bold hover:bg-blue-50 transition-all flex items-center gap-2 whitespace-nowrap shadow-lg shadow-blue-900/20"
            >
              Go to Dashboard
            </Link>
            <button 
              disabled={isSeeding}
              onClick={handleSeed}
              className="bg-blue-700 text-white px-6 py-2 rounded-full font-bold hover:bg-blue-800 transition-all flex items-center gap-2 whitespace-nowrap shadow-lg shadow-blue-900/20 disabled:opacity-50"
            >
              {isSeeding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              {isSeeding ? 'Seeding...' : 'Seed Live Database'}
            </button>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative pt-12 md:pt-20 bg-gradient-to-b from-blue-50 to-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100/50 border border-blue-200 text-blue-700 rounded-full text-xs font-bold uppercase tracking-widest">
                <TrendingUp className="w-3.5 h-3.5" />
                Fresh Insights Everyday
              </div>
              <h1 className="text-5xl md:text-7xl font-bold font-display leading-[1.1] text-gray-900">
                Sharpen Your <span className="text-blue-600">Mind</span>, Master Your <span className="text-blue-600 italic">Day</span>.
              </h1>
              <p className="text-xl text-gray-500 max-w-lg leading-relaxed">
                Modern strategies for productivity, technology tools, and personal growth. We cut through the noise to deliver clarity.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link 
                  to="/category/productivity" 
                  className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 text-center flex items-center justify-center gap-2 group"
                >
                  Start Reading
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link 
                  to="/about" 
                  className="bg-white border border-gray-200 text-gray-700 px-8 py-4 rounded-2xl font-bold hover:bg-gray-50 transition-all text-center"
                >
                  Learn More
                </Link>
              </div>
              
              <div className="flex items-center gap-6 pt-4">
                <div className="flex -space-x-3">
                  {[1,2,3,4].map(i => (
                    <img key={i} src={`https://i.pravatar.cc/100?img=${i+10}`} className="w-10 h-10 rounded-full border-2 border-white" />
                  ))}
                </div>
                <p className="text-sm text-gray-500 font-medium">Joined by <span className="text-gray-900 font-bold">12,000+</span> readers</p>
              </div>
            </div>
            
            <div className="relative">
              <div className="aspect-square relative rounded-3xl overflow-hidden shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500 border-8 border-white">
                <img src={featuredPost.image} className="w-full h-full object-cover" />
              </div>
              {/* Floating Cards */}
              <div className="absolute -bottom-6 -left-6 md:-left-12 bg-white p-4 rounded-2xl shadow-xl border border-gray-100 flex items-center gap-4 animate-bounce-slow">
                <div className="bg-green-100 p-2 rounded-lg"><Zap className="w-6 h-6 text-green-600" /></div>
                <div>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-tight">AI Tools</p>
                  <p className="text-sm font-bold text-gray-900">Weekly Top 10 Picks</p>
                </div>
              </div>
              <div className="absolute -top-6 -right-6 bg-white p-4 rounded-2xl shadow-xl border border-gray-100 flex items-center gap-4 animate-pulse-slow">
                <div className="bg-orange-100 p-2 rounded-lg"><Target className="w-6 h-6 text-orange-600" /></div>
                <div>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-tight">Strategy</p>
                  <p className="text-sm font-bold text-gray-900">Productivity Audit</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Background blobs */}
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-blue-100 rounded-full blur-[120px] -mr-48 opacity-60"></div>
        <div className="absolute bottom-0 left-1/4 w-64 h-64 bg-blue-50 rounded-full blur-[100px] -mb-32 opacity-40"></div>
      </section>

      {/* Categories Bar */}
      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-center gap-3 py-10 border-y border-gray-100">
            <span className="text-gray-400 text-xs font-bold uppercase tracking-[0.2em] mr-4 mb-2 md:mb-0">Explore Topics:</span>
            {CATEGORIES.map(cat => (
              <Link 
                key={cat.slug} 
                to={`/category/${cat.slug}`}
                className="px-6 py-2.5 rounded-full border border-gray-100 bg-gray-50 text-gray-600 text-sm font-semibold hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-3xl font-bold font-display">Editor's Pick</h2>
          <Link to="/archives" className="text-blue-600 font-bold text-sm uppercase tracking-widest hover:underline">View All</Link>
        </div>
        <BlogCard post={featuredPost} variant="featured" />
      </section>

      {/* Latest & Sidebar Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-8 space-y-12">
            <div>
              <div className="flex items-center gap-4 mb-10">
                <h2 className="text-3xl font-bold font-display leading-none">Latest Stories</h2>
                <div className="h-px bg-gray-100 flex-grow"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {latestPosts.map(post => (
                  <BlogCard key={post.id} post={post} />
                ))}
              </div>
            </div>
            
            {/* Inline Newsletter */}
            <Newsletter />
            
            {/* More posts can go here */}
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-12">
            {/* Ad Slot */}
            <AdSlot label="Sidebar Ad" type="vertical" className="w-full hidden lg:flex" />

            {/* Popular Posts */}
            <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100">
              <h3 className="text-xl font-bold mb-6 font-display">Trending Now</h3>
              <div className="space-y-2 divide-y divide-gray-100">
                {BLOG_POSTS.slice(0, 4).map(post => (
                  <BlogCard key={post.id} post={post} variant="small" />
                ))}
              </div>
            </div>

            {/* Topics Card */}
            <div className="bg-blue-600 p-8 rounded-3xl text-white">
              <h3 className="text-xl font-bold mb-6 font-display">Browse Topics</h3>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map(cat => (
                  <Link 
                    key={cat.slug} 
                    to={`/category/${cat.slug}`}
                    className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/10 rounded-xl text-sm font-medium transition-colors"
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Sticky Sidebar Ad */}
            <div className="sticky top-24">
              <AdSlot label="Sticky Sidebar Ad" type="square" className="w-full" />
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
};
