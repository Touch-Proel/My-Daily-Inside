import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import { Clock, User, Calendar, Share2, Facebook, Twitter, Linkedin, MessageSquare, ChevronRight, ArrowLeft, Zap, Loader2 } from 'lucide-react';
import { BLOG_POSTS } from '../constants/blogData';
import { formatDate } from '../lib/utils';
import { AdSlot } from '../components/layout/AdSlot';
import { Newsletter } from '../components/layout/Newsletter';
import { BlogCard } from '../components/blog/BlogCard';
import { blogService } from '../services/blogService';
import { BlogPost } from '../types';

export const Post: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    async function loadPost() {
      if (!slug) return;
      setLoading(true);
      try {
        const result = await blogService.getPostBySlug(slug);
        setPost(result);
      } catch (error) {
        console.error("Failed to fetch post:", error);
      } finally {
        setLoading(false);
      }
    }
    loadPost();
  }, [slug]);

  useEffect(() => {
    const handleScroll = () => {
      const winScroll = document.documentElement.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolled = (winScroll / height) * 100;
      setScrollProgress(scrolled);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (loading) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
        <p className="text-gray-500 font-medium italic">Opening article...</p>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-4">
        <h1 className="text-4xl font-bold font-display">Post Not Found</h1>
        <p className="text-gray-500 italic">The article you are looking for doesn't exist.</p>
        <Link to="/" className="text-blue-600 font-bold hover:underline">Back to Home</Link>
      </div>
    );
  }

  const relatedPosts = BLOG_POSTS.filter(p => p.category === post.category && p.id !== post.id).slice(0, 3);

  return (
    <div className="pb-20">
      {/* Scroll Progress bar */}
      <div 
        className="fixed top-[80px] left-0 h-1 bg-blue-600 z-50 transition-all duration-100 ease-out" 
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Article Header */}
      <header className="pt-12 md:pt-16 pb-12 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <nav className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-400 mb-8">
            <Link to="/" className="hover:text-blue-600">Home</Link>
            <ChevronRight className="w-3 h-3" />
            <Link to={`/category/${post.category.toLowerCase().replace(/ & /g, '-').replace(/ /g, '-')}`} className="hover:text-blue-600">{post.category}</Link>
          </nav>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-display text-gray-900 leading-[1.15] mb-8">
            {post.title}
          </h1>

          <div className="flex flex-wrap items-center gap-6 pb-4 md:pb-0">
            <div className="flex items-center gap-3">
              <img src={`https://i.pravatar.cc/100?u=${post.author}`} className="w-12 h-12 rounded-full border border-gray-100 shadow-sm" />
              <div>
                <p className="text-sm font-bold text-gray-900">{post.author}</p>
                <p className="text-xs text-gray-500">Editorial Team Member</p>
              </div>
            </div>
            
            <div className="h-10 w-px bg-gray-100 hidden md:block"></div>
            
            <div className="grid grid-cols-2 lg:flex lg:items-center gap-6">
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Calendar className="w-4 h-4 text-gray-300" />
                {formatDate(post.publishedAt)}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Clock className="w-4 h-4 text-gray-300" />
                {post.readingTime}
              </div>
            </div>

            <div className="ml-auto flex items-center gap-3">
              <button className="p-2.5 rounded-full bg-gray-50 text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-all">
                <Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Featured Image */}
      <div className="max-w-5xl mx-auto px-4 mb-16">
        <div className="aspect-[21/9] rounded-3xl overflow-hidden shadow-2xl border-4 border-white shadow-blue-100/50">
          <img src={post.image} className="w-full h-full object-cover" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Main Article Content */}
          <article className="lg:col-span-8">
            {/* Table of Contents Placeholder */}
            <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 mb-10 overflow-hidden relative">
              <div className="absolute top-0 right-0 p-2 opacity-5"><Zap className="w-24 h-24" /></div>
              <h3 className="text-lg font-bold mb-4 font-display">In this article:</h3>
              <nav className="space-y-2">
                <a href="#section-1" className="block text-gray-600 hover:text-blue-600 text-sm font-medium transition-colors">1. The Shift from Interaction to Autonomy</a>
                <a href="#section-2" className="block text-gray-600 hover:text-blue-600 text-sm font-medium transition-colors">2. Why Choice Matters in Productive Work</a>
                <a href="#section-3" className="block text-gray-600 hover:text-blue-600 text-sm font-medium transition-colors">3. Leveraging Modern Digital Blueprints</a>
                <a href="#conclusion" className="block text-gray-600 hover:text-blue-600 text-sm font-medium transition-colors">4. Summary and Final Thoughts</a>
              </nav>
            </div>

            {/* The actual content rendered from Markdown */}
            <div className="markdown-body">
              <ReactMarkdown>{post.content}</ReactMarkdown>
            </div>

            {/* In-article Ad */}
            <AdSlot label="In-Article Content Ad" className="my-12 px-8 py-10" />

            {/* Social Share Bottom */}
            <div className="mt-16 pt-8 border-t border-gray-100 flex flex-wrap items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <p className="text-sm font-bold text-gray-400 uppercase tracking-widest leading-none">Share this post:</p>
                <div className="flex gap-2">
                  <button className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center hover:bg-blue-700 transition-colors"><Facebook className="w-5 h-5" /></button>
                  <button className="w-10 h-10 rounded-lg bg-sky-400 text-white flex items-center justify-center hover:bg-sky-500 transition-colors"><Twitter className="w-5 h-5" /></button>
                  <button className="w-10 h-10 rounded-lg bg-blue-700 text-white flex items-center justify-center hover:bg-blue-800 transition-colors"><Linkedin className="w-5 h-5" /></button>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 font-medium text-xs">
                {['Growth', 'Technology', 'Focus', 'Future'].map(tag => (
                  <span key={tag} className="px-3 py-1.5 bg-gray-100 text-gray-500 rounded-lg">#{tag}</span>
                ))}
              </div>
            </div>

            {/* Related Posts */}
            {relatedPosts.length > 0 && (
              <div className="mt-20">
                <h3 className="text-2xl font-bold font-display mb-8">Related Articles</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {relatedPosts.map(p => (
                    <BlogCard key={p.id} post={p} />
                  ))}
                </div>
              </div>
            )}
            
            {/* Newsletter */}
            <Newsletter className="mt-20" />
          </article>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-12">
            <div className="sticky top-28 space-y-12">
              <AdSlot label="Sidebar Box Ad" type="vertical" className="hidden lg:flex" />

              {/* Newsletter Small */}
              <div className="bg-gray-900 text-white p-8 rounded-3xl relative overflow-hidden group">
                <div className="relative z-10">
                  <h3 className="text-xl font-bold mb-3 font-display">Clarity into your inbox.</h3>
                  <p className="text-gray-400 text-sm mb-6">Join 12,000+ others who get our better-thinking updates every Monday.</p>
                  <Link to="/subscribe" className="block w-full bg-blue-600 text-center py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors">Join Now</Link>
                </div>
                <Zap className="absolute bottom-[-20%] right-[-10%] w-32 h-32 text-white/5 group-hover:rotate-12 transition-transform duration-500" />
              </div>

              {/* Latest in Category */}
              <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                <h3 className="text-xl font-bold mb-6 font-display">Latest in {post.category}</h3>
                <div className="space-y-4">
                   {BLOG_POSTS.slice(0, 5).map(p => (
                      <Link key={p.id} to={`/post/${p.slug}`} className="flex gap-3 group">
                        <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                          <img src={p.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold leading-tight line-clamp-2 group-hover:text-blue-600 transition-colors uppercase tracking-tight italic">{p.title}</h4>
                          <span className="text-[10px] text-gray-400 font-bold uppercase mt-1 block">5 days ago</span>
                        </div>
                      </Link>
                   ))}
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};
