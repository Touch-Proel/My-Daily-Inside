import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageSquare, Briefcase, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { blogService } from '../services/blogService';

export const Contact: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'sending' | 'success'>('idle');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'General Inquiry',
    message: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    try {
      await blogService.submitContactMessage(formData);
      setStatus('success');
      setFormData({ name: '', email: '', subject: 'General Inquiry', message: '' });
    } catch (error) {
      console.error("Message failed to send:", error);
      setStatus('idle');
      alert("Failed to send message. Please try again later.");
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="pb-20">
      <header className="pt-20 pb-20 bg-white text-center border-b border-gray-50">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-bold font-display italic mb-8">Get in <span className="text-blue-600">Touch</span>.</h1>
          <p className="text-xl text-gray-500 leading-relaxed italic max-w-2xl mx-auto">
            Questions, feedback, or collaborations? We'd love to hear from you. Fill out the form below and we'll get back to you within 48 hours.
          </p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Contact Info */}
          <div className="lg:col-span-5 space-y-10">
            <div className="grid grid-cols-1 gap-6">
              <div className="p-8 bg-gray-50 rounded-3xl border border-gray-100 flex items-start gap-6 group hover:translate-x-2 transition-transform duration-300">
                 <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200">
                    <Mail className="w-6 h-6" />
                 </div>
                 <div>
                    <h3 className="text-lg font-bold font-display mb-1 uppercase tracking-tight italic">Email Us</h3>
                    <p className="text-gray-500 mb-2">For general inquiries and press</p>
                    <a href="mailto:hello@mydailyinsight.com" className="text-blue-600 font-bold hover:underline">hello@mydailyinsight.com</a>
                 </div>
              </div>

              <div className="p-8 bg-gray-50 rounded-3xl border border-gray-100 flex items-start gap-6 group hover:translate-x-2 transition-transform duration-300">
                 <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200">
                    <Briefcase className="w-6 h-6" />
                 </div>
                 <div>
                    <h3 className="text-lg font-bold font-display mb-1 uppercase tracking-tight italic">Work with Us</h3>
                    <p className="text-gray-500 mb-2">For sponsorships and ads</p>
                    <a href="mailto:ads@mydailyinsight.com" className="text-blue-600 font-bold hover:underline">ads@mydailyinsight.com</a>
                 </div>
              </div>

              <div className="p-8 bg-gray-50 rounded-3xl border border-gray-100 flex items-start gap-6 group hover:translate-x-2 transition-transform duration-300">
                 <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200">
                    <MapPin className="w-6 h-6" />
                 </div>
                 <div>
                    <h3 className="text-lg font-bold font-display mb-1 uppercase tracking-tight italic">Location</h3>
                    <p className="text-gray-500 mb-2">Our digital headquarters</p>
                    <p className="text-gray-900 font-bold italic">San Francisco, CA / Remote</p>
                 </div>
              </div>
            </div>

            <div className="bg-blue-600 rounded-3xl p-10 text-white relative overflow-hidden group">
               <div className="relative z-10">
                 <h3 className="text-2xl font-bold mb-4 font-display italic">Subscribe to the Insight</h3>
                 <p className="text-blue-100 mb-8 leading-relaxed">Join thousands who start their week with our curated intelligence digest.</p>
                 <Link to="/about" className="inline-block bg-white text-blue-600 px-8 py-3 rounded-xl font-bold hover:bg-blue-50 transition-colors uppercase tracking-widest text-xs">Join Today</Link>
               </div>
               <Zap className="absolute bottom-[-20%] right-[-10%] w-48 h-48 text-white/5 group-hover:rotate-12 transition-transform duration-700" />
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-[40px] p-8 md:p-12 border border-gray-100 shadow-xl shadow-gray-100/50">
               {status === 'success' ? (
                 <div className="text-center py-20 animate-in fade-in zoom-in">
                    <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
                       <Send className="w-10 h-10" />
                    </div>
                    <h2 className="text-3xl font-bold font-display mb-4 italic">Message Sent!</h2>
                    <p className="text-gray-500 max-w-sm mx-auto mb-10 leading-relaxed italic">
                       Thank you for reaching out. A human from our team will evaluate your message and respond shortly.
                    </p>
                    <button 
                      onClick={() => setStatus('idle')}
                      className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-colors uppercase tracking-tight"
                    >
                      Send Another
                    </button>
                 </div>
               ) : (
                 <form onSubmit={handleSubmit} className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-2">
                          <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-2">Your Name</label>
                          <input 
                            required
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            type="text" 
                            placeholder="John Doe" 
                            className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium italic"
                          />
                       </div>
                       <div className="space-y-2">
                          <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-2">Email Address</label>
                          <input 
                            required
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            type="email" 
                            placeholder="john@example.com" 
                            className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium italic"
                          />
                       </div>
                    </div>
                    
                    <div className="space-y-2">
                       <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-2">Subject</label>
                       <select 
                         name="subject"
                         value={formData.subject}
                         onChange={handleChange}
                         className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium italic appearance-none"
                       >
                          <option>General Inquiry</option>
                          <option>Collaboration / Sponsorship</option>
                          <option>Article Suggestion</option>
                          <option>Technical Issue</option>
                          <option>Other</option>
                       </select>
                    </div>

                    <div className="space-y-2">
                       <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-2">Message</label>
                       <textarea 
                         required
                         name="message"
                         value={formData.message}
                         onChange={handleChange}
                         rows={6} 
                         placeholder="How can we help you today?" 
                         className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-gray-900 font-medium italic resize-none"
                       ></textarea>
                    </div>

                    <button 
                      disabled={status === 'sending'}
                      type="submit" 
                      className="w-full bg-blue-600 text-white py-5 rounded-2xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-200 flex items-center justify-center gap-3 group disabled:opacity-50"
                    >
                      {status === 'sending' ? 'Sending Insights...' : (
                        <>
                          Send Message
                          <MessageSquare className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                        </>
                      )}
                    </button>
                    
                    <p className="text-center text-xs text-gray-400 italic">
                      By submitting this form, you agree to our <Link to="/privacy-policy" className="underline">Privacy Policy</Link>.
                    </p>
                 </form>
               )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
