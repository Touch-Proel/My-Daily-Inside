import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CATEGORIES, BLOG_POSTS } from '../constants/blogData';
import { BlogCard } from '../components/blog/BlogCard';
import { AdSlot } from '../components/layout/AdSlot';
import { ChevronRight, Loader2 } from 'lucide-react';
import { blogService } from '../services/blogService';
import { BlogPost } from '../types';

export const CategoryPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const category = CATEGORIES.find(c => c.slug === slug);
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadCategoryPosts() {
      if (!category) return;
      setLoading(true);
      try {
        const results = await blogService.getPostsByCategory(category.name);
        setPosts(results);
      } catch (error) {
        console.error("Failed to fetch category posts:", error);
      } finally {
        setLoading(false);
      }
    }
    loadCategoryPosts();
  }, [category, slug]);

  if (!category) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
        <h1 className="text-3xl font-bold font-display">Category Not Found</h1>
        <p className="text-gray-500 mt-2">The topic you are looking for does not exist on our blog.</p>
        <Link to="/" className="mt-8 text-blue-600 font-bold hover:underline">Back to Home</Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
        <p className="text-gray-500 font-medium italic">Filtering insights...</p>
      </div>
    );
  }

  return (
    <div className="pb-20">
      <header className="bg-blue-600 text-white pt-16 pb-24 md:pb-32 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <nav className="flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-blue-200 mb-8">
            <Link to="/" className="hover:text-white">Home</Link>
            <ChevronRight className="w-3 h-3" />
            <span>Category</span>
          </nav>
          <h1 className="text-4xl md:text-6xl font-bold font-display mb-6">{category.name}</h1>
          <p className="max-w-2xl mx-auto text-blue-100/80 text-lg sm:text-xl font-medium leading-relaxed">
            {category.description}
          </p>
        </div>
        
        {/* Abstract background shape */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full fill-white">
            <path d="M0 0 L100 0 L100 100 Q 50 80 0 100 Z" />
          </svg>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Posts Area */}
          <div className="lg:col-span-8">
            <div className="space-y-12">
              {posts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {posts.map(post => (
                    <BlogCard key={post.id} post={post} />
                  ))}
                </div>
              ) : (
                <div className="bg-white p-20 rounded-[40px] text-center border border-gray-100 shadow-xl shadow-gray-100/50">
                  <p className="text-xl text-gray-500 italic">More articles coming soon to the {category.name} section!</p>
                </div>
              )}

              {/* Ad Slot in middle of infinity scroll (simulated) */}
              <AdSlot label="In-feed Category Ad" type="horizontal" className="shadow-sm" />

              {/* Pagination Placeholder */}
              {posts.length > 0 && (
                <div className="flex items-center justify-center gap-2 pt-12">
                  <button className="w-12 h-12 rounded-xl bg-gray-100 text-gray-400 flex items-center justify-center cursor-not-allowed">1</button>
                  <button className="w-12 h-12 rounded-xl border border-gray-100 text-gray-600 hover:bg-gray-50 flex items-center justify-center">2</button>
                  <button className="w-12 h-12 rounded-xl border border-gray-100 text-gray-600 hover:bg-gray-50 flex items-center justify-center">3</button>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-12">
            <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
              <h3 className="text-xl font-bold mb-6 font-display">Other Topics</h3>
              <div className="space-y-3">
                {CATEGORIES.filter(c => c.slug !== slug).map(cat => (
                  <Link 
                    key={cat.slug} 
                    to={`/category/${cat.slug}`}
                    className="flex items-center justify-between group py-3 px-4 rounded-xl hover:bg-blue-50 transition-colors border border-transparent hover:border-blue-100"
                  >
                    <span className="font-bold text-gray-700 group-hover:text-blue-600 transition-colors uppercase tracking-tight italic">{cat.name}</span>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-blue-400 transition-colors" />
                  </Link>
                ))}
              </div>
            </div>

            <AdSlot label="Category Sidebar Ad" type="vertical" heightClass="h-[450px]" className="lg:flex hidden" />
            
            <div className="sticky top-24">
               <div className="bg-gray-900 rounded-3xl p-8 text-white">
                  <h3 className="text-xl font-bold mb-4 font-display italic">Sign up for more.</h3>
                  <p className="text-gray-400 text-sm mb-6">Get notified when we publish new insights about {category.name}.</p>
                  <input type="email" placeholder="Your email..." className="w-full bg-white/10 border border-white/20 rounded-xl py-3 px-4 mb-4" />
                  <button className="w-full bg-blue-600 py-3 rounded-xl font-bold">Subscribe</button>
               </div>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
};
