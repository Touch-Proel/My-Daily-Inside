import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.GEMINI_API_KEY || "";

const ai = new GoogleGenAI({ apiKey: API_KEY });

export interface GeneratedArticle {
  title: string;
  slug: string;
  description: string;
  content: string;
  category: string;
  readingTime: string;
}

export async function generateArticle(prompt: string, category: string): Promise<GeneratedArticle> {
  if (!API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured. Please add it in Settings.");
  }

  const systemInstruction = `You are a world-class professional blog writer and SEO strategist specializing in high-quality, original content that ranks on Google and is suitable for AdSense approval.

CONTENT REQUIREMENTS (DO NOT INCLUDE IN CONTENT BODY):
- SEO TITLE: Create a catchy, click-worthy, and SEO-optimized title for the "title" field.
- META DESCRIPTION: Create an engaging description under 160 characters for the "description" field.
- URL SLUG: Create a clean, url-friendly slug for the "slug" field.

MARKDOWN CONTENT BODY REQUIREMENTS (FOR THE "content" FIELD):
- DO NOT repeat the Title or Description inside the content body.
- HEADINGS (CRITICAL): Use Markdown H2 (##) for main sections and H3 (###) for subsections. Ensure a logical hierarchy.
- PRACTICAL TIPS: Include actionable advice and specific "how-to" steps.
- COMMON MISTAKES: Add a section detailing what readers should avoid.
- CHECKLIST: Provide a clear, actionable checklist for the topic.
- REAL-LIFE EXAMPLE: Include at least one relatable scenario or case study.
- 5 FAQ: Provide five relevant questions and clear, helpful answers.
- CONCLUSION: Summarize key takeaways with a helpful closing tone.

QUALITY GUIDELINES:
- TONE: Clear, helpful, friendly, and trustworthy.
- LANGUAGE: Use simple English suitable for international readers.
- LENGTH: Aim for a comprehensive depth of 1,200–1,500 words.
- ORIGINALITY: Content must be entirely unique and avoid exaggerated claims.
- AD SENSE FRIENDLY: Professional, safe, and informative content.

The response MUST be a valid JSON object.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "SEO optimized Meta Title" },
            slug: { type: Type.STRING, description: "URL friendly slug" },
            description: { type: Type.STRING, description: "Engaging Meta Description (150-160 chars)" },
            content: { type: Type.STRING, description: "Full article content in Markdown format. Use actual newline characters, not escaped strings." },
            category: { type: Type.STRING, description: "The category name provided" },
            readingTime: { type: Type.STRING, description: "Estimated reading time (e.g. '7 min read')" }
          },
          required: ["title", "slug", "description", "content", "category", "readingTime"]
        }
      }
    });

    const text = response.text.trim();
    const result = JSON.parse(text) as GeneratedArticle;
    
    // Fix literal \n strings that sometimes occur in JSON responses from LLMs
    if (result.content) {
      result.content = result.content.replace(/\\n/g, '\n');
    }
    
    // Ensure category matches what was passed in if AI tried to change it
    result.category = category;
    
    return result;
  } catch (error) {
    console.error("Error generating article:", error);
    if (error instanceof Error && error.message.includes("401")) {
      throw new Error("Invalid API Key. Please check your GEMINI_API_KEY in Settings.");
    }
    throw new Error("Failed to generate article with AI. Please try again.");
  }
}
