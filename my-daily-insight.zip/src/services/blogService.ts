import { 
  collection, 
  getDocs, 
  getDoc, 
  doc, 
  query, 
  where, 
  orderBy, 
  limit, 
  addDoc, 
  updateDoc,
  deleteDoc,
  serverTimestamp,
  type DocumentData,
  type QuerySnapshot
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { BlogPost, Category } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const blogService = {
  async getPosts(categoryName?: string, limitCount: number = 10, includeFuture: boolean = false): Promise<BlogPost[]> {
    const path = 'posts';
    try {
      const constraints: any[] = [orderBy('publishedAt', 'desc'), limit(limitCount)];
      
      if (!includeFuture) {
        constraints.push(where('publishedAt', '<=', new Date().toISOString()));
      }
      
      if (categoryName) {
        constraints.push(where('category', '==', categoryName));
      }
      
      const q = query(collection(db, path), ...constraints);
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as BlogPost));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  async getPostBySlug(slug: string, includeFuture: boolean = false): Promise<BlogPost | null> {
    const path = 'posts';
    try {
      const constraints: any[] = [where('slug', '==', slug), limit(1)];
      if (!includeFuture) {
        constraints.push(where('publishedAt', '<=', new Date().toISOString()));
      }
      const q = query(collection(db, path), ...constraints);
      const snapshot = await getDocs(q);
      if (snapshot.empty) return null;
      const docData = snapshot.docs[0];
      return { id: docData.id, ...docData.data() } as BlogPost;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
      return null;
    }
  },

  async getPostsByCategory(categoryName: string, includeFuture: boolean = false): Promise<BlogPost[]> {
    const path = 'posts';
    try {
      const constraints: any[] = [
        where('category', '==', categoryName),
        orderBy('publishedAt', 'desc')
      ];
      if (!includeFuture) {
        constraints.push(where('publishedAt', '<=', new Date().toISOString()));
      }
      const q = query(collection(db, path), ...constraints);
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as BlogPost));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  async submitContactMessage(message: { name: string; email: string; subject: string; message: string }) {
    const path = 'messages';
    try {
      await addDoc(collection(db, path), {
        ...message,
        createdAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },

  async createPost(post: Omit<BlogPost, 'id'>) {
    const path = 'posts';
    try {
      const docRef = await addDoc(collection(db, path), post);
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },

  async updatePost(id: string, post: Partial<BlogPost>) {
    const path = `posts/${id}`;
    try {
      const postRef = doc(db, 'posts', id);
      await updateDoc(postRef, post);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async deletePost(id: string) {
    const path = `posts/${id}`;
    try {
      const postRef = doc(db, 'posts', id);
      await deleteDoc(postRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Helper to seed logic for the admin
  async seedPosts(posts: Omit<BlogPost, 'id'>[]) {
    const path = 'posts';
    try {
      for (const post of posts) {
        await addDoc(collection(db, path), post);
      }
    } catch (error) {
      console.error("Seeding failed: ", error);
    }
  }
};
