import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth();
export const googleProvider = new GoogleAuthProvider();

export const signInWithGoogle = () => signInWithPopup(auth, googleProvider);
export const logout = () => signOut(auth);

async function testConnection() {
  console.log("Testing Firestore connection to database:", firebaseConfig.firestoreDatabaseId);
  try {
    // Basic connectivity check
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("✅ Firestore connection successful.");
  } catch (error: any) {
    console.error("❌ Firestore connection test failed:", error.code, error.message);
    if (error.code === 'unavailable') {
      console.warn("Possible network issue or Firestore is still provisioning. The app will retry automatically.");
    }
  }
}

testConnection();
