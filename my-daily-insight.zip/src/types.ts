export type Category = 'Technology & AI' | 'Productivity' | 'Online Income' | 'Lifestyle' | 'Personal Growth';

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  description: string;
  content: string;
  category: Category;
  author: string;
  publishedAt: string;
  image: string;
  readingTime: string;
}

export interface SiteConfig {
  name: string;
  description: string;
  url: string;
  author: string;
}
